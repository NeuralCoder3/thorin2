#pragma once

#include "thorin/world.h"

#include "dialects/rusty/autogen.h"

namespace thorin::rusty {} // namespace thorin::rusty
