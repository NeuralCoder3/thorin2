#include "thorin/world.h"

#include "dialects/real/real.h"

namespace thorin::real {

const Def* normalize_const(const Def*, const Def*, const Def* arg, const Def*) {
    auto& world = arg->world();
    return world.lit_idx(world.type_idx(arg), 42);
}

THORIN_real_NORMALIZER_IMPL

} // namespace thorin::real
