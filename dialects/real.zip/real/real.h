#pragma once

#include <thorin/world.h>

#include "dialects/real/autogen.h"

namespace thorin::real {} // namespace thorin::real
